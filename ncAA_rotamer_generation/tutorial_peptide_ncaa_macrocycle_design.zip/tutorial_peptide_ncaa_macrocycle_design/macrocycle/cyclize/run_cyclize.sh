#!/bin/bash

#ROSETTA=/dors/meilerlab/apps/rosetta/rosetta-3.13/main/source/bin/rosetta_scripts.default.linuxgccrelease
ROSETTA=/usr/people/mkf/rosetta_workshop/rosetta/main/source/bin/rosetta_scripts.default.linuxgccrelease

$ROSETTA @inputs/rosetta.flags
