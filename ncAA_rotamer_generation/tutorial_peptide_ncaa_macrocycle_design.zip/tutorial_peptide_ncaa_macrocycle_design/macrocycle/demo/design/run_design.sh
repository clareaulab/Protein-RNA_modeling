#!/bin/bash

ROSETTA=/dors/meilerlab/apps/rosetta/rosetta-3.13/main/source/bin/rosetta_scripts.default.linuxgccrelease

$ROSETTA -in:file:s `ls inputs/4EXS_Dcys_Lpro_native.pdb` @inputs/rosetta.flags
#$ROSETTA -in:file:s `ls inputs/2EXS_Dcys_Lpro_native.pdb ../cyclize/output/*.pdb` @inputs/rosetta.flags
