The tutorial comes in two parts

1. Parameterization of Noncanonical AAs in `ncaa/`
2. Macrocycle design in `macrocycle/`
